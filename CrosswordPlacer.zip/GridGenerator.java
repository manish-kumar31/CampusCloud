import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class GridGenerator {
    public static void main(String[] args) {
        int SIZE = CrosswordPlacer.SIZE;
        char[][] solutionBoard = new char[SIZE][SIZE];
        for (char[] row : solutionBoard) Arrays.fill(row, '+');

        // Load random word set from CSV
        String[] words = getRandomWordSetFromCSV("crossword_word_sets.csv");


        if (words == null || words.length == 0) {
            System.out.println("❌ No valid words found in CSV.");
            return;
        }

        System.out.println("📦 Loaded Words: " + Arrays.toString(words));

        if (CrosswordPlacer.placeWords(solutionBoard, words, 0)) {

            System.out.println("\n📄 Puzzle Grid (fillable = '-', blocked = '+'):\n");
            char[][] puzzleGrid = generatePuzzleGrid(solutionBoard);
            printBoard(puzzleGrid);

            System.out.println("\n🔍 Solving Puzzle...\n");
            char[][] solvedGrid = new char[SIZE][SIZE];
            for (int i = 0; i < SIZE; i++) solvedGrid[i] = puzzleGrid[i].clone();

            if (CrosswordSolver.solve(solvedGrid, words, 0)) {
                System.out.println("✅ Solved Grid:\n");
                printBoard(solvedGrid);
            } else {
                System.out.println("❌ Could not solve the puzzle.");
            }

        } else {
            System.out.println("❌ Could not generate crossword with given words.");
        }
    }

    static char[][] generatePuzzleGrid(char[][] solution) {
        int SIZE = CrosswordPlacer.SIZE;
        char[][] puzzle = new char[SIZE][SIZE];
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                char ch = solution[row][col];
                puzzle[row][col] = (ch == '+' || ch == 'x') ? '+' : '-';
            }
        }
        return puzzle;
    }

    static void printBoard(char[][] board) {
        for (char[] row : board) {
            for (char c : row) System.out.print(c + " ");
            System.out.println();
        }
    }

    // ✅ Method to get a random word array from a CSV file
    static String[] getRandomWordSetFromCSV(String filePath) {
        List<String[]> wordSets = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] words = Arrays.stream(line.split(","))
                        .map(String::trim)
                        .filter(w -> !w.isEmpty())
                        .toArray(String[]::new);
                if (words.length >= 5) wordSets.add(words); // Minimum 5 words as you requested
            }
        } catch (IOException e) {
            System.out.println("❌ Error reading CSV: " + e.getMessage());
        }

        if (wordSets.isEmpty()) return null;
        Random random = new Random();
        return wordSets.get(random.nextInt(wordSets.size()));
    }
}
