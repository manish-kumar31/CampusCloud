import java.util.*;

public class CrosswordSolver {
    public static boolean solve(char[][] board, String[] words, int index) {
        if (index == words.length) return true;

        String word = words[index];
        int SIZE = CrosswordPlacer.SIZE;

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (canPlaceHorizontally(board, word, row, col)) {
                    boolean[] placed = placeHorizontally(board, word, row, col);

                    if (solve(board, words, index + 1)) return true;

                    unplaceHorizontally(board, placed, row, col);
                }

                if (canPlaceVertically(board, word, row, col)) {
                    boolean[] placed = placeVertically(board, word, row, col);

                    if (solve(board, words, index + 1)) return true;

                    unplaceVertically(board, placed, row, col);
                }
            }
        }

        return false;
    }

    private static boolean canPlaceHorizontally(char[][] board, String word, int row, int col) {
        int SIZE = CrosswordPlacer.SIZE;
        if (col + word.length() > SIZE) return false;

        for (int i = 0; i < word.length(); i++) {
            char cell = board[row][col + i];
            if (cell != '-' && cell != word.charAt(i)) return false;
        }

        return true;
    }

    private static boolean[] placeHorizontally(char[][] board, String word, int row, int col) {
        boolean[] placed = new boolean[word.length()];
        for (int i = 0; i < word.length(); i++) {
            if (board[row][col + i] == '-') {
                board[row][col + i] = word.charAt(i);
                placed[i] = true;
            }
        }
        return placed;
    }

    private static void unplaceHorizontally(char[][] board, boolean[] placed, int row, int col) {
        for (int i = 0; i < placed.length; i++) {
            if (placed[i]) board[row][col + i] = '-';
        }
    }

    private static boolean canPlaceVertically(char[][] board, String word, int row, int col) {
        int SIZE = CrosswordPlacer.SIZE;
        if (row + word.length() > SIZE) return false;

        for (int i = 0; i < word.length(); i++) {
            char cell = board[row + i][col];
            if (cell != '-' && cell != word.charAt(i)) return false;
        }

        return true;
    }

    private static boolean[] placeVertically(char[][] board, String word, int row, int col) {
        boolean[] placed = new boolean[word.length()];
        for (int i = 0; i < word.length(); i++) {
            if (board[row + i][col] == '-') {
                board[row + i][col] = word.charAt(i);
                placed[i] = true;
            }
        }
        return placed;
    }

    private static void unplaceVertically(char[][] board, boolean[] placed, int row, int col) {
        for (int i = 0; i < placed.length; i++) {
            if (placed[i]) board[row + i][col] = '-';
        }
    }
}
